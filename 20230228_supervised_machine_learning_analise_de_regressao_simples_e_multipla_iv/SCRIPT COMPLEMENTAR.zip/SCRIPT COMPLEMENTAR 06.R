# Exemplo 8:

modelo_renda <- lm(despmed ~ renda, planosaude_dummies)

summary(modelo_renda)

ols_vif_tol(modelo_planosaude)
ols_vif_tol(step_planosaude)
