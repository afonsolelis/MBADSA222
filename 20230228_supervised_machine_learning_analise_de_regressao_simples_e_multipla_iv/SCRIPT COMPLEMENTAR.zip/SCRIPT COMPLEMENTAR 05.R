# Exemplo 7:

saeb_rend$yhat <- modelosaeb$fitted.values #não funciona com missing values
saeb_rend$yhat <- predict(object = modelosaeb, newdata = saeb_rend)

saeb_rend$resid <- modelosaeb$residuals #não funciona com missing values
saeb_rend$resid <- saeb_rend$saeb - saeb_rend$yhat

saeb_rend$up <- ((saeb_rend$resid)^2)/((sum(saeb_rend$resid^2, na.rm = TRUE))/(25530))

modelo_aux <- lm(formula = up ~ yhat,
                 data = saeb_rend)
anova(modelo_aux)

pchisq(33.441/2, df = 1, lower.tail = F)

saeb_rend$yhat <- NULL
saeb_rend$resid <- NULL
saeb_rend$up <- NULL


############
# Referência: Acre
saeb_rend_dummies_uf <- dummy_columns(.data = saeb_rend,
                                      select_columns = "uf",
                                      remove_selected_columns = T,
                                      remove_first_dummy = T)

modelosaeb_dummies_uf <- lm(formula = saeb ~ . -municipio -codigo -escola -rede,
                            data = saeb_rend_dummies_uf)

summary(modelosaeb_dummies_uf)

ols_test_breusch_pagan(modelosaeb_dummies_uf)

############
# Referência: Bahia
saeb_rend_dummies_uf <- dummy_columns(.data = saeb_rend,
                                      select_columns = "uf",
                                      remove_selected_columns = T)

saeb_rend_dummies_uf <- saeb_rend_dummies_uf[,-11]

modelosaeb_dummies_uf <- lm(formula = saeb ~ . -municipio -codigo -escola -rede,
                            data = saeb_rend_dummies_uf)

summary(modelosaeb_dummies_uf)

ols_test_breusch_pagan(modelosaeb_dummies_uf)






