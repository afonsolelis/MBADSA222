# Exemplo 6:
chart.Correlation((salarios[2:8]), histogram = TRUE)

###
modelo1_step <- step(modelo1, k = (qchisq(p = 0.05, df = 1, lower.tail = F)))
summary(modelo1_step)

modelo_econ1 <- lm(formula = salario ~ econometria1,
                   data = salarios)
summary(modelo_econ1)

ols_vif_tol(modelo1)

###
modelo_rh3 <- lm(formula = salario ~ rh3,
                 data = salarios)
summary(modelo_rh3)

modelo3_step <- step(modelo3, k = (qchisq(p = 0.05, df = 1, lower.tail = F)))
summary(modelo3_step)

modelo_aux3 <- lm(formula = rh3 ~ econometria3,
                  data = salarios)
summary(modelo_aux3)

tolerance = 1 - 0.07027
tolerance

VIF <- 1/tolerance
VIF

###
modelo_aux2 <- lm(formula = rh2 ~ econometria2,
                  data = salarios)
summary(modelo_aux2)

tolerance2 <- 1 - summary(modelo_aux2)$r.squared
tolerance2

vif2 <- 1/tolerance2
vif2

modelo2_step <- step(modelo2, k = (qchisq(p = 0.05, df = 1, lower.tail = F)))
summary(modelo2_step)

export_summs(modelo1, modelo2_step, scale=F)

modelo_aux2_1 <- lm(formula = salario ~ econometria2,
                  data = salarios)
summary(modelo_aux2_1)
